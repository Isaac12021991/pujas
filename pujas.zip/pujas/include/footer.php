	<!-- ============================================= --> 
	<footer class="footer">
		<div class="container"> 
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<center>
						<a href="index"><img class="footer-logo" src="img/logo.png" alt=""></a>
						<h3>CONTACTANOS</h3>
						<h5>+ (1234) 12345678</h5>
						<h5>Contacto Whatsapp ó Ticket de Soporte </h5>
						<h6>contacto@latinclub.net</h6>
						<div class="f-social-box">
							<ul>
								<li><a href="#"><i class="fa fa-facebook facebook-cl"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter twitter-cl"></i></a></li>
								<li><a href="#"><i class="fa fa-instagram instagram-cl"></i></a></li>
							</ul>
						</div>
					</center>
				</div>	     
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="copyright text-center">
						<p>©Copyright <?php echo date('Y')?> LATIN CLUB Todos los derechos reservados.</p>		  
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- ============================================= --> 