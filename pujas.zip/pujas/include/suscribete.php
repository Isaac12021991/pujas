	<!-- ============================================= --> 
	<section class="newsletter theme-bg" style="background-image:url(assets/img/bg-new.png)">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<div class="heading light">
						<h2>Se parte de nuestra comunidad Suscribete</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3">
					<div class="newsletter-box text-center">
						<form method="POST">
							<div class="input-group"> <span class="input-group-addon"><span class="ti-email theme-cl"></span></span>
								<input type="text" name="correo_boletin" id="correo_boletin" class="form-control" placeholder="Ingresa tu email">
							</div>
							<button type="button" id="boletin" class="btn theme-btn btn-radius btn-m">Suscribete</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ============================================= --> 