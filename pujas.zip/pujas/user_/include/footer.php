	<!-- ================================================== -->
	<footer class="footer" style="background-color: #C9E8C9;">
		<div class="container">
			<span class="text-muted"><center>©Copyright 2021 <font color="000000">LATIN CLUB</font> Todos los derechos reservados.</center></span>
		</div>
	</footer>
	<!-- ================================================== -->