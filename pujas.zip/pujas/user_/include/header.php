	<!-- ================================================== -->
	<header>
		<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
			<a class="navbar-brand" href="index"><img src="img/favicon.jpeg" style="border-radius: 10px;" width="50"></a>

			<div class="saldo_celular" id="saldo"></div>	

			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarCollapse">
				<ul class="navbar-nav mr-auto">
					|
					<li class="nav-item active">
						<a class="nav-link btn btn-success" style=" background-color: #072B00; border-radius: 10px; color: #D6A602;" href="index"><center>INICIO</center></a>
					</li>
					|
					<li class="nav-item active">
						<a class="nav-link btn btn-success" style=" background-color: #072B00; border-radius: 10px; color: #D6A602;" href="index-salas"><center>REMATES</center></a>
					</li>
					|
					<li class="nav-item active">
						<a class="nav-link btn btn-success" style=" background-color: #072B00; border-radius: 10px; color: #D6A602;" href="resultados"><center>RESULTADOS</center></a>
					</li>
					|
					<li class="nav-item active">
						<a class="nav-link btn btn-success" style=" background-color: #072B00; border-radius: 10px; color: #D6A602;" href=""><center>TRANSMISIÓN EN VIVO</center></a>
					</li>
					|
					<li class="nav-item active">
						<a class="nav-link btn btn-success" style=" background-color: #072B00; border-radius: 10px; color: #D6A602;" href="perfil"><center>MI CUENTA</center></a>
					</li>
					|
					<li class="nav-item active">
						<a class="nav-link btn btn-success" style=" background-color: #072B00; border-radius: 10px; color: #D6A602;" href="soporte"><center>SOPORTE</center></a>
					</li>
					|
				</ul>

				<ul class="navbar-nav mr-auto">
					
					<div id="saldo2"></div>

				</ul>	
				<center>
					<a class="nav-link btn btn-danger" style=" background-color: #072B00; border-radius: 10px; color: #D6A602;" href="desconectar"><center><img src="img/salir.png" width="25"></center></a>
				</div>
			</nav>
		</header>
		<!-- ================================================== -->