        <!--****** Footer ******-->
        <div class="footer">
        	<div class="copyright">
        		<p>©Copyright <?php echo date('Y')?> <a style="color: #7AF4ED;">LATIN CLUB</a> Todos los derechos reservados.</p>
        	</div>
        </div>
        <!--****** Footer ******-->