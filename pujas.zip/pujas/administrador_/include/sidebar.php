        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">

                    <li><a class="ai-icon" href="index" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Inicio</span>
						</a>
                    </li>


                    <li><a class="ai-icon" href="usuarios" aria-expanded="false">
                            <i class="flaticon-381-heart"></i>
                            <span class="nav-text">Usuarios</span>
                        </a>
                    </li>

                    <li><a class="ai-icon" href="salas" aria-expanded="false">
                            <i class="flaticon-381-notepad"></i>
                            <span class="nav-text">Remate</span>
                        </a>
                    </li>

                    <li><a class="ai-icon" href="soporte" aria-expanded="false">
                            <i class="flaticon-381-network"></i>
                            <span class="nav-text">Soporte</span>
                        </a>
                    </li>

                    <li><a class="ai-icon" href="pagina-principal" aria-expanded="false">
                            <i class="flaticon-381-television"></i>
                            <span class="nav-text">Pagina principal</span>
                        </a>
                    </li>

                    <li><a class="ai-icon" href="reglas-salas" aria-expanded="false">
                            <i class="flaticon-381-television"></i>
                            <span class="nav-text">Reglas de puja</span>
                        </a>
                    </li>


                    <li><a class="ai-icon" href="boletines" aria-expanded="false">
                            <i class="flaticon-381-notepad"></i>
                            <span class="nav-text">boletines</span>
                        </a>
                    </li>
                    

                    <li><a class="ai-icon" href="configuracion-porcentaje" aria-expanded="false">
                            <i class="flaticon-381-controls-3"></i>
                            <span class="nav-text">Porcentaje pagos</span>
                        </a>
                    </li>

                </ul>

				<div class="copyright">
					<p>Hecho por <i class="fa fa-heart text-danger"></i> <a href="https://chiphysiweb.com/" style="color: #7AF4ED;" target="_black">chiphysi SAS</a></p>
				</div>
			</div>
        </div>